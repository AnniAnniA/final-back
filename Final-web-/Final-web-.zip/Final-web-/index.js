require('dotenv').config(); // Load environment variables from .env file

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt')
const nodemailer = require("nodemailer");

const app = express();
const port = process.env.PORT || 3000; // Use port from environment variable or default to 3000
app.use(express.static('public'));

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URL)
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch((err) => {
        console.error('Error connecting to MongoDB:', err.message);
    });

// Define user schema
const userSchema = new mongoose.Schema({
    email: String,
    username: { type: String, unique: true },
    password: String,
    firstName: String,
    lastName: String,
    age: Number,
    country: String,
    gender: String,
    role: { type: String, enum: ['user', 'admin', 'editor'], default: 'user' },  // Default is 'user'
    createdAt: { type: Date, default: Date.now }
});
const itemSchema = new mongoose.Schema({
    username: String,
    picture1: String,
    picture2: String,
    picture3: String,
    names: String,
    descriptions: String,
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: null },
    deletedAt: { type: Date, default: null }
});

const User = mongoose.model('User', userSchema);
const Item = mongoose.model('Item', itemSchema); // Create model for item

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'secret-key', resave: false, saveUninitialized: true }));

const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

// Set the view engine to ejs
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

app.get('/register', (req, res) => {
    res.render('register', { message: '' }); // Pass an empty message initially
});

app.post('/register', async (req, res) => {
    try {
        const { email, username, password, firstName, lastName, age, country, gender, role } = req.body;

        // Check if username already exists
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.render('register', { message: 'User already exists. Choose a different username.' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create a new user with the selected role
        const user = new User({
            email,
            username,
            password: hashedPassword,
            firstName,
            lastName,
            age,
            country,
            gender,
            role: role || 'user'  // Default role is 'user' if none is selected
        });

        // Save user to the database
        await user.save();

        // Send welcome email
        const recipient = email;
        const info = await transporter.sendMail({
            from: 'your-email@gmail.com',
            to: recipient,
            subject: "Welcome to our platform",
            text: "Thank you for registering with us!"
        });

        res.redirect('/');
    } catch (error) {
        res.status(500).send(error.message);
    }
});



// Function to validate password
function validatePassword(password) {
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d!@#$%^&*()_+]{8,}$/;
    return passwordRegex.test(password);
}

app.get('/login', (req, res) => {
    res.render('login', { message: '' }); // Pass an empty message initially
});


app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // Find the user by username
    const user = await User.findOne({ username });

    // Check if the user exists and if the password is correct
    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.render('login', { message: 'Incorrect username or password. Please try again.' });
    }

    // Store the user ID (or username) in the session
    req.session.userId = user.username;

    // Check the user's role and redirect accordingly
    if (user.role === 'admin') {
        return res.redirect('/admin'); // Admin dashboard
    } else if (user.role === 'editor') {
        return res.redirect('/editor'); // Editor dashboard
    } else {
        return res.redirect('/dashboard'); // Regular user dashboard
    }
});

function checkRole(requiredRole) {
    return (req, res, next) => {
        const userId = req.session.userId;
        if (!userId) {
            return res.redirect('/login');  // If not logged in, redirect to login page
        }

        // Fetch the user from the database to check the role
        User.findOne({ username: userId }).then(user => {
            if (!user) {
                return res.redirect('/login');  // If user does not exist, redirect to login
            }

            // Check if user role matches required role
            if (user.role === requiredRole) {
                return next();  // Proceed to the next route handler if the role matches
            } else {
                return res.status(403).send('Forbidden: You do not have access to this page.');
            }
        }).catch(err => {
            res.status(500).send('Error checking user role: ' + err.message);
        });
    };
}


// Route to handle adding new items
// Route to handle adding new items
app.post('/admin/add-item', async (req, res) => {
    try {
        // Assuming you handle the add item logic here...
        const newItem = new Item(req.body);
        await newItem.save();

        // Redirecting back to /admin with a success message
        res.redirect('/admin?message=Item added successfully!');
    } catch (error) {
        res.redirect('/admin?message=Error adding item.');
    }
});


// Route to handle editing existing items

app.post('/admin/edit-item', checkRole('admin'), async (req, res) => {
    const { objectId, names, descriptions } = req.body;
    try {
        if (!mongoose.isValidObjectId(objectId)) {
            return res.status(400).send('Invalid objectId');
        }
        await Item.findByIdAndUpdate(objectId, { names, descriptions, updatedAt: Date.now() });
        res.redirect('/admin');
    } catch (error) {
        res.status(500).send(error.message);
    }
});




// Route to handle soft deletion of items
app.post('/admin/delete-item/:itemId', checkRole('admin'), async (req, res) => {
    const { itemId } = req.params;
    try {
        await Item.findByIdAndDelete(itemId);
        res.redirect('/admin');
    } catch (error) {
        res.status(500).send(error.message);
    }
});


app.get('/dashboard', async (req, res) => {
    if (!req.session.userId) {
        res.redirect('/login');
    } else {
        try {
            // Find items where the username matches the logged-in user's username
            const items = await Item.find({ username: req.session.userId });
            res.render('dashboard', { items });
        } catch (error) {
            res.status(500).send(error.message);
        }
    }
});
app.get('/timezone', (req, res) => {
    res.render('timezone', { message: '' }); // Pass an empty message initially
});
app.get('/random', (req, res) => {
    res.render('random', { message: '' }); // Pass an empty message initially
});
app.get('/location', (req, res) => {
    res.render('location', { message: '' }); // Pass an empty message initially
});

// Admin dashboard

app.get('/admin', async (req, res) => {
    try {
        const items = await Item.find();  // Fetch all items from the database

        // Passing 'message' along with 'items' to the template
        const message = req.query.message || '';  // Default to an empty string if no message is provided

        res.render('admin', { items, message });  // Render the page with items and message
    } catch (error) {
        res.status(500).send(error.message);
    }
});


app.get('/editor-dashboard', checkRole('editor'), async (req, res) => {
    try {
        // You can show specific content to the editor user
        res.render('editor-dashboard');
    } catch (error) {
        res.status(500).send(error.message);
    }
});



app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/');
        }
        res.clearCookie('connect.sid');
        res.redirect('/');
    });
});


// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
